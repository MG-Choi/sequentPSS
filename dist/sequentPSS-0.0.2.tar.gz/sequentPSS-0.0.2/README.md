# sequentPSS
sequential parameter space search method based on global sensitivity analysis
